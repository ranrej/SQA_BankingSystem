class Transaction:
    def __init__(self, code, account_number, amount, misc_data):
        self.code = code
        self.account_number = account_number
        self.amount = amount
        self.misc_data = misc_data

    @staticmethod
    def parse_transaction_line(line):
        parts = line.strip().split(",")
        if len(parts) < 4:
            return None
        return Transaction(parts[0], parts[1], float(parts[2]), parts[3])
