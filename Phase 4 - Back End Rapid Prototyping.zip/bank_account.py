class BankAccount:
    def __init__(self, account_number, name, status, balance, transaction, plan):
        self.account_number = account_number
        self.name = name
        self.status = status
        self.balance = balance
        self.transaction = transaction
        self.plan = plan

    def apply_transaction(self, transaction_type, amount):
        if transaction_type == "deposit":
            self.balance += amount
        elif transaction_type == "withdrawal" and self.balance >= amount:
            self.balance -= amount
        else:
            return False  # Failed transaction due to insufficient balance or unknown type
        return True

    def apply_transaction_fee(self, fee):
        self.balance -= fee

    def to_master_file_format(self):
        return f"{self.account_number},{self.name},{self.status},{self.balance},{self.transaction},{self.plan}\n"
