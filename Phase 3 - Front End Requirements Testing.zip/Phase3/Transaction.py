import os
# from User import User
# from Transaction import Transaction
# from Account import Account
# from Bank import Bank
# from File import File

# -----------------------------------
# Class: Transaction
# Represents a banking transaction such as withdrawal, deposit, or transfer.
# -----------------------------------
class Transaction:
    def __init__(self, session_type: str, amount: float = 0.0, receiver_number: str = "", company_name: str = ""):
        """
        Initializes a Transaction object.
        :param session_type: Type of transaction session
        :param amount: Transaction amount
        :param receiver_number: Receiver's account number (if applicable)
        :param company_name: Name of the company (if applicable)
        """
        self.session_type = session_type
        self.amount = amount
        self.receiver_number = receiver_number
        self.company_name = company_name
    
    def withdraw(self, amount: float):
        """
        Performs a withdrawal transaction.
        :param amount: Amount to withdraw
        """
        self.amount = amount
    
    def change_plan(self, new_plan: str):
        """
        Change the transaction plan.
        """
        self.plans = new_plan
    
    def transfer(self, receiver_number: str, amount: float):
        """
        Transfer amount.
        """
        self.receiver_number = receiver_number
        self.amount = amount
    
    def pay_bill(self, company_name: str, amount: float):
        """
        Pay a bill.
        """
        self.company_name = company_name
        self.amount = amount
    
    def deposit(self, amount: float):
        """
        Performs a deposit transaction.
        :param amount: Amount to deposit
        """
        self.amount = amount
    
    def get_holder_name(self):
        """
        Return holder name.
        """
        return self.holder_name
    
    def get_account_number(self):
        """
        Return account number.
        """
        return self.number
