import sys
import os
from User import User
# from Transaction import Transaction
from Account import Account
from Bank import Bank
# from File import File

class BankingSystem:
    """
    This class represents the core banking system that manages user sessions,
    account transactions, and bank operations.
    """
    def __init__(self):
        """
        Initializes the banking system by loading accounts and setting up session variables.
        """
        self.bank = Bank()
        self.logged_in = False
        self.admin_mode = False
        self.current_user = None
        self.current_account = None
        self.accounts_file = None
        self.atf_file = None
        self.transaction_list = []
        self.save_transactions_enabled = True 
    
    def load_accounts(self, filename):
        """
        Loads accounts from a file and stores them in the bank's account list.
        """
        if os.path.exists(filename):
            with open(filename, "r") as file:
                for line in list(file)[:-1]:
                    # strips \n from end of line, splits the string on "_" and filters any empty strings ""
                    account_info = list(filter(None, line.strip().split("_")))
                    acc_num, first_name, last_name, status, balance = account_info
                    acc_name = first_name + " " + last_name
                    self.bank.accounts.append(Account(acc_name, acc_num, "", status, float(balance)))
                    # print(acc_num, acc_name, status, balance)
    

    def format_transaction(self, transaction_code, holder_name, account_number, amount, misc="00"):
        f_name, l_name = holder_name.split(" ")
        holder_name = (f_name + "_" + l_name).ljust(20, "_")[:20]  # Left-align and pad to 20 characters
        account_number = account_number.zfill(5)  # Right-align, zero-padded to 5 digits
        amount_str = f"{float(amount):08.2f}"  # Right-align, zero-padded, two decimal places
        misc = misc.ljust(2)[:2]  # Ensure misc field is exactly 2 characters

        self.transaction_list.append(f"{transaction_code}_{holder_name}_{account_number}_{amount_str}_{misc}")


    def save_transactions(self, atf_file):
        """
        Saves transaction history to a file.
        """

        if not self.save_transactions_enabled:
            return
        
        # print(self.transaction_list)        
        with open(atf_file, "w") as file:
            for transaction in self.transaction_list:
                file.write(f'{transaction}\n')
            file.write("00______________________00000_00000.00_00")

    
    def login(self):
        """
        Handles user login based on session type.
        """
        if self.logged_in:
            print("Error: Already logged in.")
            return
        

        session_type = input("Enter session type (standard/admin): ").strip().lower()
        
        if session_type == "admin":
            self.admin_mode = True
        elif session_type == "standard":
            self.admin_mode = False
            if sys.stdout.isatty():
                user_name = input("Enter account holder name: ").strip()
            else:
                print("\nEnter account holder name: ", end='')
                user_name = sys.stdin.readline().strip()
            for account in self.bank.accounts:
                if account.holder_name == user_name:
                    if account.status == "D":
                        if sys.stdout.isatty():
                            print("Account is disabled.")
                        else:
                            print("\nAccount is disabled.")
                        return
                    self.current_user = User(user_name, id=0)
                    self.current_account = account
                    break
            if not self.current_account:
                print("Invalid account holder name.")
                return
        else:
            if sys.stdout.isatty():
                print("Invalid session type.")
            else:
                print("\nInvalid session type.")
            return
        
        self.logged_in = True

        # Needed for testing (to match exact output): only adds new line if saving to file, else no new line
        if not sys.stdout.isatty():
            print()

        print("Login successful.")

    def withdrawal(self):
        """
        Handles withdrawal transactions.
        """
        if not self.logged_in:
            print("Error: Must be logged in.")
            return
        
        if self.admin_mode and self.logged_in:
            if sys.stdout.isatty():
                user_name = input("Enter account holder name: ").strip()
            else:
                print("Enter account holder name: ", end='')
                user_name = sys.stdin.readline().strip()
        elif not self.admin_mode and self.logged_in:
            if not self.current_user == None:
                user_name = self.current_user.name
            else:
                user_name = None
        

        if sys.stdout.isatty():
            acc_num = input("Enter account number: ")
        else:
            if self.admin_mode:
                print("\nEnter account number: ", end='')
                acc_num = sys.stdin.readline().strip()
            else:
                print("Enter account number: ", end='')
                acc_num = sys.stdin.readline().strip()

        
        no_acc = False
        # can generalize this (like a different function rather than using in login and withdrawal)
        for account in self.bank.accounts:
            # print(f'-{account.holder_name}-,-{account.number}-,-{user_name}-,-{acc_num}-')
            if account.holder_name == user_name and account.number == acc_num:
                # print(f'True')
                self.current_user = User(user_name, id=0)
                self.current_account = account
                no_acc = False
                break
            else:
                # print("False")
                no_acc = True
        
        
        if not no_acc:
            if sys.stdout.isatty():
                amount = float(input("Enter amount to withdraw: "))
            else:
                print("\nEnter amount to withdraw: ", end='')
                amount = float(sys.stdin.readline().strip())
            
            # taken care of in login
            # if self.current_account.status == "D":
            #     if sys.stdout.isatty():
            #         print("Error: Account is disabled.---")
            #     else:
            #         print("\nError: Account is disabled.+++")
            #     return
            
            if amount > 500 and not self.admin_mode:
                if sys.stdout.isatty():
                    print("Error: Cannot withdraw more than $500 in standard mode.")
                else:
                    print("\nError: Cannot withdraw more than $500 in standard mode.")
                return
            
            if self.current_account.balance - amount < 0:
                if sys.stdout.isatty():
                    print("Error: Insufficient funds.")
                else:
                    print("\nError: Insufficient funds.")
                return
            
            self.current_account.balance -= amount
            self.format_transaction("01", self.current_account.holder_name, self.current_account.number, amount)

            if sys.stdout.isatty():
                print("Withdrawal successful.")
            else:
                print("\nWithdrawal successful.")
        else:
            if sys.stdout.isatty():
                print("Invalid account information.")
            else:
                print("\nInvalid account information.")

    def transfer(self):
        """
        Handles transfer transactions between two accounts.
        """
        if not self.logged_in:
            print("Error: Must be logged in.")
            return

        if sys.stdout.isatty():
            target_acc_num = input("Enter target account number: ").strip()
        else:
            print("Enter target account number: ", end='')
            target_acc_num = sys.stdin.readline().strip()

        target_account = next((acc for acc in self.bank.accounts if acc.number == target_acc_num), None)

        if not target_account:
            print("Invalid target account number.")
            return

        if sys.stdout.isatty():
            amount = float(input("Enter amount to transfer: "))
        else:
            print("Enter amount to transfer: ", end='')
            amount = float(sys.stdin.readline().strip())

        if amount > 1000 and not self.admin_mode:
            print("Error: Cannot transfer more than $1000 in standard mode.")
            return

        if self.current_account.balance < amount:
            print("Error: Insufficient funds.")
            return

        self.current_account.balance -= amount
        target_account.balance += amount

        self.format_transaction("02", self.current_account.holder_name, self.current_account.number, amount)

        print("Transfer successful.")

    def pay_bill(self):
        """
        Handles bill payment transactions.
        """
        if not self.logged_in:
            print("Error: Must be logged in.")
            return

        if sys.stdout.isatty():
            company_name = input("Enter company name: ").strip()
        else:
            print("Enter company name: ", end='')
            company_name = sys.stdin.readline().strip()

        if sys.stdout.isatty():
            amount = float(input("Enter amount to pay: "))
        else:
            print("Enter amount to pay: ", end='')
            amount = float(sys.stdin.readline().strip())

        if amount > 1000 and not self.admin_mode:
            print("Error: Cannot pay more than $1000 in standard mode.")
            return

        if self.current_account.balance < amount:
            print("Error: Insufficient funds.")
            return

        self.current_account.balance -= amount

        self.format_transaction("03", self.current_account.holder_name, self.current_account.number, amount, company_name[:2].upper())

        print("Bill payment successful.")

    def deposit(self):
        """
        Tests -> :
        1) The user must be logged in.
        2) If admin, user must enter a valid account holder name (no numbers/special chars).
        3) The account number must match an existing account.
        4) The deposit amount must be positive.
        5) A standard user cannot access deposited funds immediately (if we store them as pending).
        6) The account must be active (status == 'A') for deposits.
        """

        # Check if the user is logged in
        if not self.logged_in:
            print("Error: You must be logged in to deposit.")
            return

    
        if self.admin_mode:
            # For admin
            holder_name = input("Enter account holder name: ").strip()
            
            # Validate the name (no digits/special chars)
            if len(holder_name) == 0:
                print("Error: Invalid name (cannot be empty).")
                return
            for ch in holder_name:
                if not (ch.isalpha() or ch.isspace()):
                    print("Error: Invalid name (no numbers or special characters).")
                    return

            # Prompt for the account number
            acc_num = input("Enter account number: ").strip()

            # Search for the matching account
            target_account = None
            for acct in self.bank.accounts:
                if acct.holder_name == holder_name and acct.number == acc_num:
                    target_account = acct
                    break
            
            if not target_account:
                print("Error: Invalid account number.")
                return

            # Check if the account is active 
            if target_account.status != "A":
                print("Error: Account is not active.")
                return
            
            # Prompt for deposit amount 
            try:
                amount_str = input("Enter amount to deposit: ").strip()
                amount = float(amount_str)
            except ValueError:
                print("Error: Invalid deposit amount.")
                return
            
            if amount <= 0:
                print("Error: Deposit amount must be positive.")
                return

            # Update the account balance immediately for admin
            target_account.balance += amount
            self.format_transaction("04", target_account.holder_name, target_account.number, amount)
            print("Deposit successful.")

        else:
            # For a standard user, deposit into their own current account
            if self.current_account is None:
                print("Error: No current account to deposit into.")
                return
            
            # The account must be active 
            if self.current_account.status != "A":
                print("Error: Account is not active.")
                return
            
            # Ask for the deposit amount 
            try:
                amount_str = input("Enter amount to deposit: ").strip()
                amount = float(amount_str)
            except ValueError:
                print("Error: Invalid deposit amount.")
                return
            
            if amount <= 0:
                print("Error: Deposit amount must be positive.")
                return

            
            self.current_account.balance += amount
            self.format_transaction("04", self.current_account.holder_name, self.current_account.number, amount)
            
            print("Deposit successful")
    
    def create(self):
        """
        Tests -> :
        1) The user must be logged in and must be an admin.
        2) The account holder's name must be valid – it should be 1 to 20 characters long and contain only letters and spaces.
        3) The initial balance must be a valid number between $1 and $99999.99.
        4) The system must generate a unique 5-digit account number for the new account.
        5) The new account is created with an active status.
        6) Newly created accounts should not be allowed to perform other transactions in the same session.
        """
    
        if not self.logged_in:
            print("Error: You must log in first.")
            return
        
        if not self.admin_mode:
            print("Error: Only an admin can create accounts.")
            return

        # Ask for the account holder's name
        name = input("Enter account holder's name: ").strip()
        if len(name) == 0 or len(name) > 20:
            print("Error: Name must be 1 to 20 characters.")
            return

        # Check each character to ensure it's a letter or space
        for char in name:
            if not (char.isalpha() or char.isspace()):
                print("Error: Invalid name. No numbers or special characters allowed.")
                return

        # Ask for the initial balance
        try:
            balance_str = input("Enter initial balance: ").strip()
            balance = float(balance_str)
        except ValueError:
            print("Error: Invalid balance. Please enter a number.")
            return

        # Check balance range
        if balance < 1 or balance > 99999.99:
            print("Error: Balance must be between $1 and $99999.99.")
            return

        # Find the highest existing account number
        max_num = 0
        for acct in self.bank.accounts:
            try:
                acct_num_int = int(acct.number)
                if acct_num_int > max_num:
                    max_num = acct_num_int
            except ValueError:
                # If the account number isn't a number, ignore it
                pass

        new_number = max_num + 1       # Increment the max number by 1
        new_str = str(new_number)      # Convert the new number to a string
    

        while len(new_str) < 5:
            new_str = "0" + new_str
        new_acc_num = new_str

        # Make the new account (status 'A' for active)
        new_account = Account(name, new_acc_num, "", "A", balance)
        self.bank.accounts.append(new_account)

        # Record the transaction (05 for 'create')
        self.format_transaction("05", new_account.holder_name, new_account.number, balance)

        print("Account created successfully.")
    
    def change_plan(self):
        """
        Changes the plan for the current user's account.
        """
        if not self.admin_mode:
            print("Error: Must be logged in as admin to change plan.")
            return

        if sys.stdout.isatty():
            new_plan = input("Enter new plan type (S/C): ").strip().upper()
        else:
            print("Enter new plan type (S/C): ", end='')
            new_plan = sys.stdin.readline().strip().upper()

        if new_plan not in ("S", "C"):
            print("Invalid plan type.")
            return

        self.current_account.plan = new_plan

        self.format_transaction("04", self.current_account.holder_name, self.current_account.number, "0.00", new_plan)

        print("Plan change successful.")
    
    def disable(self):
        """
        Disables an account (admin only).
        """
        if not self.admin_mode:
            print("Error: Must be logged in as admin to disable account.")
            return

        if sys.stdout.isatty():
            acc_num = input("Enter account number to disable: ").strip()
        else:
            print("Enter account number to disable: ", end='')
            acc_num = sys.stdin.readline().strip()

        account = next((acc for acc in self.bank.accounts if acc.number == acc_num), None)

        if not account:
            print("Invalid account number.")
            return

        account.status = "D"

        self.format_transaction("05", account.holder_name, account.number, "0.00")

        print("Account disabled successfully.")
    
    def delete(self):
        """
        Tests -> :
        Lets an admin delete an existing account if:
        1) The user is logged in and is an admin.
        2) The account holder name and account number match a real account.
        3) The account is not disabled (cannot delete a disabled account).
        4) Once deleted, the account status is changed to "Deleted."
        """

        # Check if someone is logged in
        if not self.logged_in:
            print("Error: You must be logged in to delete an account.")
            return

        # Check if the user is an admin
        if not self.admin_mode:
            print("Error: Only admin can delete accounts.")
            return

        # Ask for the account holder's name
        holder_name = input("Enter account holder name: ").strip()

        # Ask for the account number
        account_num = input("Enter account number: ").strip()

        # Search for the matching account in our bank's account list
        target_account = None
        for acct in self.bank.accounts:
            if acct.holder_name == holder_name and acct.number == account_num:
                target_account = acct
                break

        # If no account is found, print an error and stop
        if target_account is None:
            print("Error: Account holder or account number not found.")
            return

        # If the account is disabled, we cannot delete it
        if target_account.status == "D":
            print("Error: This account is disabled and cannot be deleted.")
            return

        # Mark the account as deleted
        target_account.status = "Deleted"

        # Record the delete transaction (e.g., code "06" for delete)
        self.format_transaction("06", target_account.holder_name, target_account.number, 0)

        # Print success message
        print("Account deleted successfully.")
    
    def logout(self):
        """
        Logs out the current user and saves transactions.
        """
        if not self.logged_in:
            print("Error: No active session.")
            self.save_transactions(self.atf_file)
            return
        
        self.save_transactions(self.atf_file)
        self.logged_in = False
        self.admin_mode = False
        self.current_user = None
        self.current_account = None
        print("Logout successful.")
    
    def run(self):
        """
        Runs the banking system, allowing users to enter commands.
        """

        account_file = sys.argv[1]
        self.atf_file = sys.argv[2]


        self.load_accounts(account_file)

        # just for testing
        if sys.stdout.isatty():
            print("Welcome to the Banking System!")
            print("-------------------------------")
            print("Please choose a transaction (enter number):\n0 - Exit\n1 - Login\n2 - Withdraw\n3 - Transfer\n4 - Pay Bill\n5 - Deposit\n6 - Create\n7 - Change Plan\n8 - Disable\n9 - Delete\n10 - Logout")


        while True:
            
            # to print options after each transaction (so user know what to choose from, can remove if needed and just keep print statement at end of login function) 
            # if self.logged_in or self.admin_mode:
            # print("Please choose a transaction (enter number):\n0 - Exit\n1 - Login\n2 - Withdraw\n3 - Pay Bill\n4 - Deposit\n5 - Create\n6 - Change Plan\n7 - Disable\n8 - Delete\n9 - Logout")
            
            # Needed for testing (to match exact output): if testing, reads from file, else from terminal
            if not sys.stdout.isatty():
                command = sys.stdin.readline().strip().lower()
            else:
                command = input("Enter command: ").strip().lower()

            if command == "1":
                self.login()
            elif command == "2":
                self.withdrawal()
            elif command == "3":
                self.transfer()
            elif command == "4":
                self.pay_bill()
            elif command == "5":
                self.deposit()
            elif command == "6":
                self.create()
            elif command == "7":
                self.change_plan()
            elif command == "8":
                self.disable()
            elif command == "9":
                self.delete()
            elif command == "10":
                self.logout()
            # add something that either logs user out when exiting or tells the user to mamually logout before exiting
            elif command == "0":
                if not sys.stdout.isatty():
                    print("Session Terminated!", end='')  # Add newline if redirected to a file
                else:
                    print("Session Terminated!")  # Avoid newline if in terminal
                break
            else:
                print("Invalid command.")
