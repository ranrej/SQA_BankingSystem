import os
# from User import User
# from Transaction import Transaction
# from Account import Account
# from Bank import Bank
# from File import File

# -----------------------------------
# Class: User
# Represents a bank user with a name, ID, and optional address.
# -----------------------------------
class User:
    def __init__(self, name: str, id: int, address: str = ""):
        """
        Initializes a User object.
        :param name: Name of the user
        :param id: Unique user ID
        :param address: Optional address
        """
        self.name = name
        self.id = id
        self.address = address
    
    def display_info(self):
        """
        Displays user information.
        """
        print(f"User: {self.name}, ID: {self.id}, Address: {self.address}")

