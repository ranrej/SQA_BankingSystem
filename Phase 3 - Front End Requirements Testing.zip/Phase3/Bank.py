import os
# from User import User
# from Transaction import Transaction
# from Account import Account
# from Bank import Bank
# from File import File

# -----------------------------------
# Class: Bank
# Represents a banking system managing multiple accounts and users.
# -----------------------------------
class Bank:
    def __init__(self):
        """
        Initializes a Bank object with empty lists of accounts and users.
        """
        self.accounts = []
        self.users = []
    
    def process_session(self):
        """
        Processes a user session.
        """
        pass
    
    def process_file(self):
        """
        Processes file.
        """
        pass
    
    def save_file(self):
        """
        Saves file.
        """
        pass
    
    def verify_login_status(self):
        """
        Verifies login status.
        """
        pass
    
    def verify_acc_name(self):
        """
        Verify the account name.
        """
        pass
    
    def verify_acc_number(self):
        """
        Verify the account number.
        """
        pass
    
    def verify_acc_status(self):
        """
        Verify the account status.
        """
        pass
    
    def verify_auth(self):
        """
        Verify the authentication.
        """
        pass

