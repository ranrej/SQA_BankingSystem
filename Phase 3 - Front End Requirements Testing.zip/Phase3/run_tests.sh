# !/bin/sh

cd tests || exit 1  # Exit if 'tests' directory doesn't exist

# Loop through all subdirectories in 'tests', sorted numerically
for dir in $(ls -d */ | sort -V); do
    for testcase in $(ls -d "$dir"*/ | sort -V); do
        for file in "$testcase"*.inp.txt; do
            if [ -f "$file" ]; then  # Check if the file exists
                echo "Running test: $file"
                python -u ../main.py "$testcase"current_accounts.txt "$testcase$(basename "$file" .inp.txt).atf.txt" < "$file" > "$testcase$(basename "$file" .inp.txt).out.txt"
                diff "$testcase$(basename "$file" .inp.txt).out.txt" "$testcase$(basename "$file" .inp.txt).bto.txt"
                diff "$testcase$(basename "$file" .inp.txt).atf.txt" "$testcase$(basename "$file" .inp.txt).etf.txt"
            fi
        done
    done
done
