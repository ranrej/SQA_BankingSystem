import os
# from User import User
# from Transaction import Transaction
# from Account import Account
# from Bank import Bank
# from File import File
from BankingSystem import BankingSystem

# -----------------------------------
# Main Program
# Runs the banking system on console.
# -----------------------------------
if __name__ == "__main__":
    banking_system = BankingSystem()
    banking_system.run()
