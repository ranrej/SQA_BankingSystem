#!/bin/bash
# Simulates a full week of banking sessions across 7 days

echo "Starting weekly simulation..."

# Set Day 0 state
cp "./final project front end/testing/CurrentBankAccounts" "Day0_master.txt"
cp "Day0_master.txt" "./final project front end/testing/CurrentBankAccounts"

# Define the test sessions for each day
declare -a DAYS=(
  "changeplan/ChangePlan1 changeplan/ChangePlan10"
  "create/Create1 create/Create2"
  "withdrawal/AdminWithdrawal1 withdrawal/StandardWithdrawal2"
  "transfer/AdminTransfer1 transfer/StandardTransfer1"
  "paybill/AdminPaybill1 paybill/StandardPaybill1"
  "delete/Delete1 disable/Disable1"
  "create/Create3 withdrawal/AdminWithdrawal3"
)

# Loop through each day and run the daily simulation
for i in {0..6}; do
  day_num=$((i + 1))
  echo "=== Day $day_num ==="

  day_sessions=${DAYS[$i]}
  bash daily.sh "Day$day_num" $day_sessions

  # Save end-of-day state
  cp "Day$day_num/master.txt" "Day${day_num}_master.txt"
  cp "Day$day_num/master.txt" "./final project front end/testing/CurrentBankAccounts"
done

echo "Weekly simulation complete."