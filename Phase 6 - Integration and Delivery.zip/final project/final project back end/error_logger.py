class ErrorLogger:
    @staticmethod
    def log_failed_constraint(transaction, reason):
        print(f"Transaction Failed: {transaction.account_number} - {reason}")

    @staticmethod
    def log_fatal_error(file, reason):
        print(f"Fatal Error in {file}: {reason}")