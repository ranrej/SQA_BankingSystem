from bank_account import *
from error_logger import *
from transaction import *


class BackendProcessor:
    def __init__(self, master_file, transaction_file):
        self.accounts = {}
        self.master_file = master_file
        self.transaction_file = transaction_file

    def load_master_accounts(self):
        try:
            with open(self.master_file, "r") as file:
                for line in file:
                    parts = line.strip().split(",")
                    if len(parts) == 6:
                        account = BankAccount(parts[0], parts[1], parts[2], float(parts[3]), int(parts[4]), parts[5])
                        self.accounts[account.account_number] = account
        except FileNotFoundError:
            ErrorLogger.log_fatal_error(self.master_file, "File not found")

    def process_transactions(self):
        try:
            with open(self.transaction_file, "r") as file:
                for line in file:
                    transaction = Transaction.parse_transaction_line(line)
                    if transaction and transaction.account_number in self.accounts:
                        account = self.accounts[transaction.account_number]
                        if not account.apply_transaction(transaction.code, transaction.amount):
                            ErrorLogger.log_failed_constraint(transaction, "Invalid transaction")
        except FileNotFoundError:
            ErrorLogger.log_fatal_error(self.transaction_file, "File not found")

    def write_new_master(self):
        with open(self.master_file, "w") as file:
            for account in self.accounts.values():
                file.write(account.to_master_file_format())

    def write_current_accounts(self):
        for account in self.accounts.values():
            print(account.to_master_file_format())  # Print current state

    def log_error(self, message):
        print(f"Error: {message}")
