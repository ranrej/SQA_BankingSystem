# test_backend_phase5.py
import pytest
from bank_account import BankAccount
from backend_processor import BackendProcessor
from transaction import Transaction
from unittest.mock import mock_open, patch

# ---------------------------------------------
# Tests for BankAccount.apply_transaction()
# Statement Coverage + Edge Cases
# ---------------------------------------------

@pytest.mark.parametrize("transaction_type, balance, amount, expected_result, expected_balance", [
    ("deposit", 100.00, 50.00, True, 150.00),                      # Simple deposit
    ("withdrawal", 100.00, 30.00, True, 70.00),                    # Valid withdrawal
    ("withdrawal", 100.00, 150.00, False, 100.00),                 # Insufficient balance
    ("unknown_type", 100.00, 10.00, False, 100.00),                # Invalid type
    ("deposit", 100.00, 0.00, True, 100.00),                       # Deposit of zero
    ("withdrawal", 100.00, 0.00, True, 100.00),                    # Withdrawal of zero
    ("deposit", 100.00, -50.00, True, 50.00),                      # Negative deposit
    ("withdrawal", 100.00, -30.00, True, 130.00),                  # Negative withdrawal
    ("withdrawal", 0.00, 0.01, False, 0.00),                       # Just below required balance
    ("deposit", 100.00, 9999999.99, True, 10000099.99),            # Large deposit
    ("withdrawal", 0.10, 0.01, True, 0.09),                        # Precision case
    ("withdrawal", 100.10, 100.00, True, 0.10),                    # Edge: exact amount
])
def test_apply_transaction(transaction_type, balance, amount, expected_result, expected_balance):
    acc = BankAccount("00001", "John Doe", "A", balance, 0, "S")
    result = acc.apply_transaction(transaction_type, amount)
    assert result == expected_result
    assert round(acc.balance, 2) == round(expected_balance, 2)

# ---------------------------------------------
# Tests for BackendProcessor.process_transactions()
# Decision + Loop Coverage + Edge Cases
# ---------------------------------------------

def mock_transaction_file(contents):
    return mock_open(read_data=contents)

def mock_master_file():
    return "00001,John Doe,A,1000.00,0,S\n00002,Jane Doe,A,500.00,0,S\n"

def test_valid_deposit_and_withdrawal(tmp_path):
    master_path = tmp_path / "master.txt"
    tx_path = tmp_path / "transactions.txt"
    master_path.write_text(mock_master_file())
    tx_path.write_text("deposit,00001,100.00,NA\nwithdrawal,00002,200.00,NA\n")
    processor = BackendProcessor(str(master_path), str(tx_path))
    processor.load_master_accounts()
    processor.process_transactions()
    assert processor.accounts['00001'].balance == 1100.00
    assert processor.accounts['00002'].balance == 300.00

def test_insufficient_funds(tmp_path):
    master_path = tmp_path / "master.txt"
    tx_path = tmp_path / "transactions.txt"
    master_path.write_text(mock_master_file())
    tx_path.write_text("withdrawal,00002,600.00,NA\n")
    processor = BackendProcessor(str(master_path), str(tx_path))
    processor.load_master_accounts()
    processor.process_transactions()
    assert processor.accounts['00002'].balance == 500.00

def test_invalid_account_number(tmp_path):
    master_path = tmp_path / "master.txt"
    tx_path = tmp_path / "transactions.txt"
    master_path.write_text(mock_master_file())
    tx_path.write_text("deposit,00099,100.00,NA\n")
    processor = BackendProcessor(str(master_path), str(tx_path))
    processor.load_master_accounts()
    processor.process_transactions()
    assert '00099' not in processor.accounts

def test_invalid_transaction_format(tmp_path):
    master_path = tmp_path / "master.txt"
    tx_path = tmp_path / "transactions.txt"
    master_path.write_text(mock_master_file())
    tx_path.write_text("invalid_line\n")
    processor = BackendProcessor(str(master_path), str(tx_path))
    processor.load_master_accounts()
    processor.process_transactions()
    assert processor.accounts['00001'].balance == 1000.00

def test_empty_transaction_file(tmp_path):
    master_path = tmp_path / "master.txt"
    tx_path = tmp_path / "transactions.txt"
    master_path.write_text(mock_master_file())
    tx_path.write_text("")
    processor = BackendProcessor(str(master_path), str(tx_path))
    processor.load_master_accounts()
    processor.process_transactions()
    assert processor.accounts['00001'].balance == 1000.00

def test_file_not_found():
    processor = BackendProcessor("missing_master.txt", "missing_tx.txt")
    processor.load_master_accounts()
    processor.process_transactions()

def test_duplicate_transactions(tmp_path):
    master_path = tmp_path / "master.txt"
    tx_path = tmp_path / "transactions.txt"
    master_path.write_text(mock_master_file())
    tx_path.write_text("deposit,00001,100.00,NA\ndeposit,00001,100.00,NA\n")
    processor = BackendProcessor(str(master_path), str(tx_path))
    processor.load_master_accounts()
    processor.process_transactions()
    assert processor.accounts['00001'].balance == 1200.00

def test_mixed_valid_invalid(tmp_path):
    master_path = tmp_path / "master.txt"
    tx_path = tmp_path / "transactions.txt"
    master_path.write_text(mock_master_file())
    tx_path.write_text("deposit,00001,100.00,NA\ninvalid_line\n")
    processor = BackendProcessor(str(master_path), str(tx_path))
    processor.load_master_accounts()
    processor.process_transactions()
    assert processor.accounts['00001'].balance == 1100.00

def test_whitespace_only_line(tmp_path):
    master_path = tmp_path / "master.txt"
    tx_path = tmp_path / "transactions.txt"
    master_path.write_text(mock_master_file())
    tx_path.write_text("   \n")
    processor = BackendProcessor(str(master_path), str(tx_path))
    processor.load_master_accounts()
    processor.process_transactions()
    assert processor.accounts['00001'].balance == 1000.00

def test_fail_then_success_sequence(tmp_path):
    master_path = tmp_path / "master.txt"
    tx_path = tmp_path / "transactions.txt"
    master_path.write_text(mock_master_file())
    tx_path.write_text("withdrawal,00002,600.00,NA\ndeposit,00002,200.00,NA\n")
    processor = BackendProcessor(str(master_path), str(tx_path))
    processor.load_master_accounts()
    processor.process_transactions()
    assert processor.accounts['00002'].balance == 700.00

def test_early_00_transaction(tmp_path):
    master_path = tmp_path / "master.txt"
    tx_path = tmp_path / "transactions.txt"
    master_path.write_text(mock_master_file())
    tx_path.write_text("00\n")
    processor = BackendProcessor(str(master_path), str(tx_path))
    processor.load_master_accounts()
    processor.process_transactions()
    assert processor.accounts['00001'].balance == 1000.00

def test_transaction_after_failed_one(tmp_path):
    master_path = tmp_path / "master.txt"
    tx_path = tmp_path / "transactions.txt"
    master_path.write_text(mock_master_file())
    tx_path.write_text("withdrawal,00002,600.00,NA\ndeposit,00002,100.00,NA\n")
    processor = BackendProcessor(str(master_path), str(tx_path))
    processor.load_master_accounts()
    processor.process_transactions()
    assert processor.accounts['00002'].balance == 600.00
