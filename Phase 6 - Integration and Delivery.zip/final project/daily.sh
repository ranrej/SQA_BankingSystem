#!/bin/bash
# Runs a set of transaction sessions for one day

FRONTEND_DIR="./final project front end"
BACKEND_DIR="./final project back end"
DAY_DIR=$1
shift  # Remove day directory argument
mkdir -p "$DAY_DIR"

echo "Running daily sessions..."

for session in "$@"; do
    echo "  Processing session: $session"

    INPUT_PATH="$FRONTEND_DIR/testing/tests/$session/input.txt"
    LOG_PATH="$DAY_DIR/$(basename $session)_transaction_log.txt"
    OUTPUT_PATH="$DAY_DIR/$(basename $session)_output.txt"

    if [ -f "$INPUT_PATH" ]; then
        cat "$INPUT_PATH" | python3 "$FRONTEND_DIR/main.py" log="$LOG_PATH" accounts="$FRONTEND_DIR/testing/CurrentBankAccounts" > "$OUTPUT_PATH"
    else
        echo "  Warning: $INPUT_PATH not found, skipping session."
    fi
done

# Merge logs from all sessions
cat "$DAY_DIR/"*_transaction_log.txt > "$DAY_DIR/merged_transactions.txt"

# Run backend using the merged log and current accounts
python3 "$BACKEND_DIR/backend_processor.py" "$FRONTEND_DIR/testing/CurrentBankAccounts" "$DAY_DIR/merged_transactions.txt"

# Save the final state of bank accounts
cp "$FRONTEND_DIR/testing/CurrentBankAccounts" "$DAY_DIR/master.txt"