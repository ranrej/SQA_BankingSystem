import os
from User import User
from Transaction import Transaction
from Account import Account
from Bank import Bank
from File import File

class BankingSystem:
    """
    This class represents the core banking system that manages user sessions,
    account transactions, and bank operations.
    """
    def __init__(self):
        """
        Initializes the banking system by loading accounts and setting up session variables.
        """
        self.bank = Bank()
        self.logged_in = False
        self.admin_mode = False
        self.current_user = None
        self.current_account = None
        self.load_accounts()
    
    def load_accounts(self):
        """
        Loads accounts from a file and stores them in the bank's account list.
        """
        if os.path.exists("bank_accounts.txt"):
            with open("bank_accounts.txt", "r") as file:
                for line in file:
                    acc_num, acc_name, status, balance = line.strip().split("_")
                    self.bank.accounts.append(Account(acc_name.strip(), acc_num, "", status, float(balance)))
    
    def save_transactions(self):
        """
        Saves transaction history to a file.
        """
        with open("transactions.txt", "w") as file:
            for account in self.bank.accounts:
                file.write(f"{account.holder_name} {account.number} {account.balance}\n")
    
    def login(self):
        """
        Handles user login based on session type.
        """
        if self.logged_in:
            print("Error: Already logged in.")
            return
        
        session_type = input("Enter session type (standard/admin): ").strip().lower()
        if session_type == "admin":
            self.admin_mode = True
        elif session_type == "standard":
            self.admin_mode = False
            user_name = input("Enter account holder name: ").strip()
            for account in self.bank.accounts:
                if account.holder_name == user_name:
                    self.current_user = User(user_name, id=0)
                    self.current_account = account
                    break
            if not self.current_account:
                print("Invalid account holder name.")
                return
        else:
            print("Invalid session type.")
            return
        
        self.logged_in = True
        print("Login successful.")
    
    def logout(self):
        """
        Logs out the current user and saves transactions.
        """
        if not self.logged_in:
            print("Error: No active session.")
            return
        
        self.save_transactions()
        self.logged_in = False
        self.admin_mode = False
        self.current_user = None
        self.current_account = None
        print("Logout successful.")
    
    def withdrawal(self):
        """
        Handles withdrawal transactions.
        """
        if not self.logged_in or not self.current_account:
            print("Error: Must be logged in.")
            return
        
        amount = float(input("Enter amount to withdraw: "))
        
        if self.current_account.status == "D":
            print("Error: Account is disabled.")
            return
        
        if amount > 500 and not self.admin_mode:
            print("Error: Cannot withdraw more than $500 in standard mode.")
            return
        
        if self.current_account.balance - amount < 0:
            print("Error: Insufficient funds.")
            return
        
        self.current_account.balance -= amount
        print("Withdrawal successful.")
    
    def run(self):
        """
        Runs the banking system, allowing users to enter commands.
        """
        while True:
            command = input("Enter command: ").strip().lower()
            if command == "login":
                self.login()
            elif command == "logout":
                self.logout()
            elif command == "withdrawal":
                self.withdrawal()
            elif command == "exit":
                print("Exiting system.")
                break
            else:
                print("Invalid command.")
