import os
from User import User
from Transaction import Transaction
from Account import Account
from Bank import Bank
from File import File

# -----------------------------------
# Class: Account
# Represents a bank account with transactions and balance management.
# -----------------------------------
class Account:
    def __init__(self, holder_name: str, number: str, plans: str, status: str, balance: float):
        """
        Initializes an Account object.
        :param holder_name: Name of the account holder
        :param number: Account number
        :param plans: Account plan type
        :param status: Account status (Active, Disabled, Deleted)
        :param balance: Current balance
        """
        self.transaction_type = ""
        self.holder_name = holder_name
        self.number = number
        self.plans = plans
        self.status = status
        self.balance = balance
    
    def login(self, session_type: str):
        """
        Logs into an account session.
        :param session_type: Type of session (admin or standard)
        """
        self.transaction_type = session_type
    
    def logout(self):
        """
        Logs out of the current session.
        """
        self.transaction_type = ""
    
    def create(self, initial_balance: float):
        """
        Sets the initial balance.
        """
        self.balance = initial_balance
    
    def disable(self):
        """
        Sets the status to disable.
        """
        self.status = "D"
    
    def delete(self):
        """
        Delete the account.
        """
        self.status = "Deleted"
    
    def transaction_history(self):
        """
        Shows transaction history.
        """
        return "Transaction history not implemented yet."
