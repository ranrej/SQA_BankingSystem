import os
from User import User
from Transaction import Transaction
from Account import Account
from Bank import Bank
from File import File

# -----------------------------------
# Class: File
# Handles file operations for storing and retrieving data.
# -----------------------------------
class File:
    def __init__(self, path: str, name: str):
        """
        Initializes a File object.
        :param path: File path
        :param name: File name
        """
        self.path = path
        self.name = name
    
    def file_exists(self):
        """
        Checks if file exists.
        """
        pass
    
    def read(self):
        """
        Reads data from the file.
        """
        pass
    
    def write(self):
        """
        Writes data to the file.
        """
        pass
    
    def get_file_path(self):
        """
        Returns file path.
        """
        return self.path
    
    def set_file_path(self, path: str):
        """
        Sets the file path.
        """
        self.path = path

